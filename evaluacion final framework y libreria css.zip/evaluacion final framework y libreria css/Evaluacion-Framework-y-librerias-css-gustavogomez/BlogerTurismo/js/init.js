// JavaScript Document
$(document).ready(function(){
      $('.parallax').parallax();
    });